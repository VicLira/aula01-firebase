<?php

    require './Array.php';

    $object = json_encode($arrayAlunos);
    $object1 = json_decode($object);

    

    
    // print_r(var_dump($object1[1]));

    // for($i = 0; $i < 10; $i++) {
    //     if($object1[$i]->media > 8) {
    //         echo "<pre>";
    //         print_r($object1[$i]->nomeAluno);
    //     };
    // }

    function createCollumn($nomeAluno) {
        print_r(
            "<td>" . $nomeAluno ."</td>"
        );

    }

    
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {
        // Some raw data (not necessarily accurate)
        var data = ([
          [ 'mounth', <?php for($i = 0; $i < 6; $i++) { echo $object1[$i]->nomeAluno . ','; }; ?>],
          ['2004/05',  165,      938,         522,             998,           450,      614.6],
          ['2005/06',  135,      1120,        599,             1268,          288,      682],
          ['2006/07',  157,      1167,        587,             807,           397,      623],
          ['2007/08',  139,      1110,        615,             968,           215,      609.4],
          ['2008/09',  136,      691,         629,             1026,          366,      569.6]
        ]);

        var options = {
          title : 'Monthly Coffee Production by Country',
          vAxis: {title: 'Cups'},
          hAxis: {title: 'Month'},
          seriesType: 'bars',
          series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>

    <link rel="stylesheet" href="./styles/main.css">
    <title>ARRAY ALUNOS</title>
</head>
<body>

<div id="listagemAlunos">
<table>
        <caption>Consumindo JSON</caption>
        <thead>
            <tr>
                <td id="reprovados">Reprovados</td>
                <td id="aprovados">Aprovados</td>
                <td id="aprovados-merito">Aprovados c/ mérito</td>
            </tr>
        </thead>
        <tbody>
            
            <tr>
                <?php 
                    for($i = 0; $i < 10; $i++) {
                        if($object1[$i]->media <= 6) {
                            createCollumn($object1[$i]->nomeAluno);
                        } 
                    }
                    
                ?>
            </tr>

            
            <tr>
                <?php 
                    for($i = 0; $i < 10; $i++) {
                        if($object1[$i]->media <= 9) {
                            createCollumn($object1[$i]->nomeAluno);
                        }   
                    }
                    
                ?>
            </tr> 

            <tr>
                <?php
                    for($i = 0; $i < 10; $i++) {
                        if($object1[$i]->media >= 10) {
                            createCollumn($object1[$i]->nomeAluno);
                        };
                    }
                    
                ?>
            </tr>
            
            </tbody>
    </table> 
</div>
    
<div id="canvas-wrapper">
    <div id="chart_div"></div>
</div>
            
        
</body>
</html>