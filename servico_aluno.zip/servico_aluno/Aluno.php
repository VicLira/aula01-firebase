<?php

    class Aluno {
        public $matriculaAluno;
        public $nomeAluno;
        public $nota1;
        public $nota2;
        public $nota3;
        public $media;

        public function __construct($matriculaAluno, $nomeAluno, $nota1, $nota2, $nota3) {
            $this->matriculaAluno = $matriculaAluno;
            $this->nomeAluno = $nomeAluno;
            $this->nota1 = $nota1;
            $this->nota2 = $nota2;
            $this->nota3 = $nota3;
            $this->media = ($nota1 + $nota2 + $nota3) / 3;
        }
    }

?>