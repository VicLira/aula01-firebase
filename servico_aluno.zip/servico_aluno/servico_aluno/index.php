<?php

    require './Array.php';

    $object = json_encode($arrayAlunos);
    $object1 = json_decode($object);

    
    // print_r(var_dump($object1[1]));

    // for($i = 0; $i < 10; $i++) {
    //     if($object1[$i]->media > 8) {
    //         echo "<pre>";
    //         print_r($object1[$i]->nomeAluno);
    //     };
    // }

    function createCollumn($nomeAluno) {
        print_r(
            "<td>" . $nomeAluno ."</td>"
        );

    }

    
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <link rel="stylesheet" href="./styles/main.css">
    <title>ARRAY ALUNOS</title>
</head>
<body>

<div id="listagemAlunos">
<table>
        <caption>Consumindo JSON</caption>
        <thead>
            <tr>
                <td id="reprovados">Reprovados</td>
                <td id="aprovados">Aprovados</td>
                <td id="aprovados-merito">Aprovados c/ mérito</td>
            </tr>
        </thead>
        <tbody>
            
            <tr>
                <?php 
                    for($i = 0; $i < 10; $i++) {
                        if($object1[$i]->media <= 6) {
                            createCollumn($object1[$i]->nomeAluno);
                        } 
                    }
                    
                ?>
            </tr>

            
            <tr>
                <?php 
                    for($i = 0; $i < 10; $i++) {
                        if($object1[$i]->media <= 9) {
                            createCollumn($object1[$i]->nomeAluno);
                        }   
                    }
                    
                ?>
            </tr> 

            <tr>
                <?php
                    for($i = 0; $i < 10; $i++) {
                        if($object1[$i]->media >= 10) {
                            createCollumn($object1[$i]->nomeAluno);
                        };
                    }
                    
                ?>
            </tr>
            
            </tbody>
    </table> 
</div>
    
<div id="canvas-wrapper">
    <canvas id="myChart"></canvas>
</div>

<script>
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Red', 'Blue', 'Yellow',],
                datasets: [{
                    label: '# of Votes',
                    data: [12, 19, 20,],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',

                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
</script>
            
        
</body>
</html>